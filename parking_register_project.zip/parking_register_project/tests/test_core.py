import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path

from parking_register import ParkingRegister, ValidationError
from parking_register.core import calc_fee, validate_plate

T0 = datetime(2026, 11, 25, 9, 0)


def fresh():
    d = tempfile.mkdtemp()
    reg = ParkingRegister(Path(d) / "p.json")
    reg.add_slot("A-01", "Car")
    reg.add_slot("C-01", "Bike")
    return reg


class CoreTests(unittest.TestCase):
    def test_validation(self):
        self.assertEqual(validate_plate("ts 08 ab 1234"), "TS08AB1234")
        for bad in ["", "123", "TS08AB12", "!!"]:
            with self.assertRaises(ValidationError):
                validate_plate(bad)
        with self.assertRaises(ValidationError):
            fresh().add_slot("A1", "Car")

    def test_checkin_checkout_fee(self):
        r = fresh()
        r.check_in("a-01", "TS08AB1234", "Ravi Kumar", 2, now=T0)
        with self.assertRaises(ValidationError):  # same vehicle twice
            r.check_in("C-01", "TS08AB1234", "Ravi Kumar", 1, now=T0)
        s = r.check_out("A-01", now=T0 + timedelta(minutes=61))
        self.assertEqual((s.hours_billed, s.fee), (2, 40))  # started hour billed
        self.assertEqual(r.get("A-01").status, "Available")

    def test_minimum_charge_and_free_accessible(self):
        self.assertEqual(calc_fee("Car", T0, T0), (1, 20))
        self.assertEqual(calc_fee("Accessible", T0, T0 + timedelta(hours=5))[1], 0)

    def test_bad_hours(self):
        r = fresh()
        for h in ["abc", 0, 25, ""]:
            with self.assertRaises(ValidationError):
                r.check_in("A-01", "TS08AB1234", "Ravi Kumar", h, now=T0)

    def test_reservation_and_maintenance(self):
        r = fresh()
        r.reserve("A-01", "Anita Rao")
        with self.assertRaises(ValidationError):
            r.check_in("A-01", "TS08AB1234", "Someone Else", 1, now=T0)
        r.check_in("A-01", "TS08AB1234", "Anita Rao", 1, now=T0)
        with self.assertRaises(ValidationError):
            r.set_maintenance("A-01", True)

    def test_overdue_warning(self):
        r = fresh()
        r.check_in("A-01", "TS08AB1234", "Ravi Kumar", 1, now=T0)
        w = r.warnings(now=T0 + timedelta(hours=3))
        self.assertTrue(any("past expected" in m for _, m in w))

    def test_persistence_roundtrip(self):
        r = fresh()
        r.check_in("A-01", "TS08AB1234", "Ravi Kumar", 1, now=T0)
        r2 = ParkingRegister.load(r.path)
        self.assertEqual(r2.get("A-01").plate, "TS08AB1234")

    def test_corrupt_and_missing_file(self):
        d = Path(tempfile.mkdtemp())
        self.assertEqual(ParkingRegister.load(d / "none.json").slots, [])
        bad = d / "bad.json"
        bad.write_text("{not json")
        r = ParkingRegister.load(bad)
        self.assertIn("corrupted", r.load_notice)
        self.assertTrue((d / "bad.corrupt.json").exists())

    def test_import_error_log(self):
        r = fresh()
        csv_text = Path("sample_data/import_with_errors.csv").read_text()
        added, errors = r.import_csv(csv_text)
        self.assertEqual(added, 3)
        self.assertEqual(len(errors), 5)
        self.assertTrue(errors[0].startswith("Row 5"))
        self.assertEqual(r.import_csv("a,b\n1,2")[0], 0)

    def test_search_and_summary(self):
        r = fresh()
        r.check_in("A-01", "TS08AB1234", "Ravi Kumar", 1, now=T0)
        self.assertEqual(len(r.search("ravi")), 1)
        self.assertEqual(len(r.search(status="Available")), 1)
        sm = r.summary(now=T0)
        self.assertEqual((sm["total"], sm["occupied"], sm["occupancy_pct"]), (2, 1, 50.0))
        self.assertIn("# Parking Slot Register", r.export_markdown(now=T0))


if __name__ == "__main__":
    unittest.main()
