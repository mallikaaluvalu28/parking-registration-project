# Parking Slot Register

Record and track parking slots and availability for a small campus lot.

## Run
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m parking_register.seed     # optional: load demo data (40 slots, 45 sessions)
streamlit run app.py
```
Tests: `python -m unittest discover -s tests -t .`

The core package needs only the standard library; Streamlit/pandas are used for the UI.
Valid plate example: `TS08AB1234`. Slot IDs look like `A-01`. Dates: `2026-11-25 14:30`.
See `PLAN.md` for architecture, rules and the demo script.
