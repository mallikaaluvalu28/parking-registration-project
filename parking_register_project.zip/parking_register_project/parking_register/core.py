"""Core logic for the Parking Slot Register: validation, persistence,
business rules, search, summaries, warnings, import and export.
Zero third-party dependencies."""
from __future__ import annotations

import csv
import io
import json
import math
import os
import re
import tempfile
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from pathlib import Path

DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "parking.json"
DT_FMT = "%Y-%m-%d %H:%M"
SLOT_TYPES = ["Car", "Bike", "EV", "Accessible"]
STATUSES = ["Available", "Occupied", "Reserved", "Maintenance"]
RATE_PER_HOUR = {"Car": 20, "Bike": 10, "EV": 30, "Accessible": 0}  # INR
ZONE_HINT = "Slot ID format: one letter, dash, two digits (e.g. A-01)"
OCCUPANCY_WARN = 0.90
LONG_STAY_HOURS = 12
CSV_FIELDS = ["slot_id", "slot_type", "status", "plate", "driver",
              "check_in", "expected_out", "notes"]

SLOT_RE = re.compile(r"^[A-Z]-\d{2}$")
PLATE_RE = re.compile(r"^[A-Z]{2}\d{1,2}[A-Z]{1,3}\d{4}$")  # e.g. TS08AB1234
NAME_RE = re.compile(r"^[A-Za-z][A-Za-z .'-]{1,39}$")


class ValidationError(ValueError):
    """Raised for any user-correctable problem."""


# ---------------------------------------------------------------- validation
def validate_slot_id(v: str) -> str:
    v = (v or "").strip().upper()
    if not SLOT_RE.match(v):
        raise ValidationError(f"Invalid slot ID '{v}'. {ZONE_HINT}.")
    return v


def validate_plate(v: str) -> str:
    v = re.sub(r"[\s-]", "", (v or "").upper())
    if not PLATE_RE.match(v):
        raise ValidationError(
            f"Invalid plate '{v}'. Expected like TS08AB1234 (state, RTO, series, number).")
    return v


def validate_name(v: str) -> str:
    v = re.sub(r"\s+", " ", (v or "").strip())
    if not NAME_RE.match(v):
        raise ValidationError("Driver name must be 2-40 letters (spaces . ' - allowed).")
    return v


def validate_hours(v) -> float:
    try:
        h = float(v)
    except (TypeError, ValueError):
        raise ValidationError("Expected duration must be a number of hours.")
    if not 0.5 <= h <= 24:
        raise ValidationError("Expected duration must be between 0.5 and 24 hours.")
    return h


def validate_type(v: str) -> str:
    v = (v or "").strip().title()
    if v == "Ev":
        v = "EV"
    if v not in SLOT_TYPES:
        raise ValidationError(f"Slot type must be one of {SLOT_TYPES}.")
    return v


def validate_status(v: str) -> str:
    v = (v or "Available").strip().title()
    if v not in STATUSES:
        raise ValidationError(f"Status must be one of {STATUSES}.")
    return v


def parse_dt(v: str) -> datetime:
    try:
        return datetime.strptime((v or "").strip(), DT_FMT)
    except ValueError:
        raise ValidationError(f"Date/time must look like 2026-11-25 14:30 (got '{v}').")


def now_min() -> datetime:
    return datetime.now().replace(second=0, microsecond=0)


# ------------------------------------------------------------------- models
@dataclass
class Slot:
    slot_id: str
    slot_type: str = "Car"
    status: str = "Available"
    plate: str = ""
    driver: str = ""
    check_in: str = ""
    expected_out: str = ""
    notes: str = ""

    @property
    def zone(self) -> str:
        return self.slot_id[0]

    def clear_vehicle(self):
        self.plate = self.driver = self.check_in = self.expected_out = ""


@dataclass
class Session:
    slot_id: str
    slot_type: str
    plate: str
    driver: str
    check_in: str
    check_out: str
    hours_billed: int
    fee: int


def calc_fee(slot_type: str, start: datetime, end: datetime) -> tuple[int, int]:
    """Billed per started hour, minimum one hour. Returns (hours, fee)."""
    minutes = max((end - start).total_seconds() / 60, 0)
    hours = max(1, math.ceil(minutes / 60))
    return hours, hours * RATE_PER_HOUR[slot_type]


# ----------------------------------------------------------------- register
class ParkingRegister:
    def __init__(self, path: Path | str = DATA_FILE):
        self.path = Path(path)
        self.slots: list[Slot] = []
        self.sessions: list[Session] = []
        self.load_notice = ""

    # --- persistence
    @classmethod
    def load(cls, path: Path | str = DATA_FILE) -> "ParkingRegister":
        reg = cls(path)
        try:
            raw = json.loads(reg.path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict) or not isinstance(raw.get("slots"), list):
                raise ValueError("schema")
            reg.slots = [Slot(**s) for s in raw["slots"]]
            reg.sessions = [Session(**s) for s in raw.get("sessions", [])]
        except FileNotFoundError:
            reg.load_notice = "No data file found - started with an empty register."
            reg.save()
        except (json.JSONDecodeError, ValueError, TypeError, KeyError):
            backup = reg.path.with_suffix(".corrupt.json")
            try:
                os.replace(reg.path, backup)
            except OSError:
                pass
            reg.slots, reg.sessions = [], []
            reg.load_notice = f"Data file was corrupted; moved to {backup.name} and started fresh."
            reg.save()
        return reg

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"version": 1, "slots": [asdict(s) for s in self.slots],
                   "sessions": [asdict(s) for s in self.sessions]}
        fd, tmp = tempfile.mkstemp(dir=self.path.parent, suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        os.replace(tmp, self.path)  # atomic: never leaves a half-written file

    # --- lookup
    def get(self, slot_id: str) -> Slot:
        sid = validate_slot_id(slot_id)
        for s in self.slots:
            if s.slot_id == sid:
                return s
        raise ValidationError(f"Slot {sid} does not exist.")

    def exists(self, slot_id: str) -> bool:
        return any(s.slot_id == slot_id for s in self.slots)

    # --- slot management
    def add_slot(self, slot_id: str, slot_type: str, notes: str = "") -> Slot:
        sid = validate_slot_id(slot_id)
        if self.exists(sid):
            raise ValidationError(f"Slot {sid} already exists.")
        slot = Slot(sid, validate_type(slot_type), notes=notes.strip()[:100])
        self.slots.append(slot)
        self.slots.sort(key=lambda s: s.slot_id)
        self.save()
        return slot

    def remove_slot(self, slot_id: str):
        slot = self.get(slot_id)
        if slot.status in ("Occupied", "Reserved"):
            raise ValidationError(f"Slot {slot.slot_id} is {slot.status}; release it first.")
        self.slots.remove(slot)
        self.save()

    def set_maintenance(self, slot_id: str, on: bool):
        slot = self.get(slot_id)
        if on:
            if slot.status == "Occupied":
                raise ValidationError("Cannot close an occupied slot.")
            slot.clear_vehicle()
            slot.status = "Maintenance"
        else:
            if slot.status != "Maintenance":
                raise ValidationError("Slot is not under maintenance.")
            slot.status = "Available"
        self.save()

    # --- parking operations
    def reserve(self, slot_id: str, driver: str):
        slot = self.get(slot_id)
        if slot.status != "Available":
            raise ValidationError(f"Slot {slot.slot_id} is {slot.status}, cannot reserve.")
        slot.driver = validate_name(driver)
        slot.status = "Reserved"
        self.save()

    def cancel_reservation(self, slot_id: str):
        slot = self.get(slot_id)
        if slot.status != "Reserved":
            raise ValidationError("Slot is not reserved.")
        slot.clear_vehicle()
        slot.status = "Available"
        self.save()

    def check_in(self, slot_id, plate, driver, expected_hours, now: datetime | None = None) -> Slot:
        now = now or now_min()
        slot = self.get(slot_id)
        plate, driver = validate_plate(plate), validate_name(driver)
        hours = validate_hours(expected_hours)
        if slot.status in ("Occupied", "Maintenance"):
            raise ValidationError(f"Slot {slot.slot_id} is {slot.status}.")
        if slot.status == "Reserved" and slot.driver.lower() != driver.lower():
            raise ValidationError(f"Slot {slot.slot_id} is reserved for {slot.driver}.")
        for s in self.slots:
            if s.status == "Occupied" and s.plate == plate:
                raise ValidationError(f"Vehicle {plate} is already parked in {s.slot_id}.")
        slot.plate, slot.driver, slot.status = plate, driver, "Occupied"
        slot.check_in = now.strftime(DT_FMT)
        slot.expected_out = (now + timedelta(hours=hours)).strftime(DT_FMT)
        self.save()
        return slot

    def check_out(self, slot_id, now: datetime | None = None) -> Session:
        now = now or now_min()
        slot = self.get(slot_id)
        if slot.status != "Occupied":
            raise ValidationError(f"Slot {slot.slot_id} is not occupied.")
        start = parse_dt(slot.check_in)
        if now < start:
            raise ValidationError("Check-out time is before check-in time.")
        hours, fee = calc_fee(slot.slot_type, start, now)
        sess = Session(slot.slot_id, slot.slot_type, slot.plate, slot.driver,
                       slot.check_in, now.strftime(DT_FMT), hours, fee)
        self.sessions.append(sess)
        slot.clear_vehicle()
        slot.status = "Available"
        self.save()
        return sess

    # --- query
    def search(self, keyword: str = "", status: str = "", slot_type: str = "",
               zone: str = "") -> list[Slot]:
        kw = (keyword or "").strip().lower()
        out = []
        for s in self.slots:
            if status and s.status != status:
                continue
            if slot_type and s.slot_type != slot_type:
                continue
            if zone and s.zone != zone:
                continue
            hay = " ".join([s.slot_id, s.plate, s.driver, s.notes, s.slot_type, s.status]).lower()
            if kw and kw not in hay:
                continue
            out.append(s)
        return out

    def search_sessions(self, keyword: str = "") -> list[Session]:
        kw = (keyword or "").strip().lower()
        return [x for x in self.sessions
                if not kw or kw in f"{x.slot_id} {x.plate} {x.driver}".lower()]

    # --- analytics
    def overdue(self, now: datetime | None = None) -> list[tuple[Slot, float]]:
        now = now or now_min()
        res = []
        for s in self.slots:
            if s.status == "Occupied" and s.expected_out:
                late = (now - parse_dt(s.expected_out)).total_seconds() / 3600
                if late > 0:
                    res.append((s, round(late, 1)))
        return sorted(res, key=lambda t: -t[1])

    def summary(self, now: datetime | None = None) -> dict:
        now = now or now_min()
        counts = Counter(s.status for s in self.slots)
        total = len(self.slots)
        usable = total - counts["Maintenance"]
        occ = counts["Occupied"]
        by_zone = {}
        for s in self.slots:
            z = by_zone.setdefault(s.zone, {"total": 0, "occupied": 0, "available": 0})
            z["total"] += 1
            z["occupied"] += s.status == "Occupied"
            z["available"] += s.status == "Available"
        by_type = Counter(s.slot_type for s in self.slots)
        revenue = sum(x.fee for x in self.sessions)
        avg_hours = (sum(x.hours_billed for x in self.sessions) / len(self.sessions)
                     if self.sessions else 0.0)
        peak = Counter()
        for x in self.sessions:
            peak[parse_dt(x.check_in).hour] += 1
        for s in self.slots:
            if s.status == "Occupied" and s.check_in:
                peak[parse_dt(s.check_in).hour] += 1
        daily = {}
        for i in range(6, -1, -1):
            daily[(now - timedelta(days=i)).strftime("%Y-%m-%d")] = {"sessions": 0, "revenue": 0}
        for x in self.sessions:
            d = x.check_out[:10]
            if d in daily:
                daily[d]["sessions"] += 1
                daily[d]["revenue"] += x.fee
        return {
            "total": total, "available": counts["Available"], "occupied": occ,
            "reserved": counts["Reserved"], "maintenance": counts["Maintenance"],
            "occupancy_pct": round(100 * occ / usable, 1) if usable else 0.0,
            "by_zone": dict(sorted(by_zone.items())), "by_type": dict(by_type),
            "sessions": len(self.sessions), "revenue": revenue,
            "avg_stay_hours": round(avg_hours, 2),
            "peak_hour": (peak.most_common(1)[0][0] if peak else None),
            "daily": daily,
        }

    def warnings(self, now: datetime | None = None) -> list[tuple[str, str]]:
        """List of (level, message); level is 'error', 'warning' or 'info'."""
        now = now or now_min()
        out = []
        for s, late in self.overdue(now):
            out.append(("error", f"{s.slot_id} ({s.plate}) is {late}h past expected check-out."))
        for s in self.slots:
            if s.status == "Occupied" and s.check_in:
                stay = (now - parse_dt(s.check_in)).total_seconds() / 3600
                if stay > LONG_STAY_HOURS:
                    out.append(("warning", f"{s.slot_id} ({s.plate}) parked {stay:.0f}h - unusually long stay."))
        sm = self.summary(now)
        if sm["occupancy_pct"] >= OCCUPANCY_WARN * 100:
            out.append(("error", f"Lot is {sm['occupancy_pct']}% full - critical capacity."))
        for z, d in sm["by_zone"].items():
            if d["total"] and d["available"] == 0:
                out.append(("warning", f"Zone {z} has no free slots."))
        if sm["maintenance"]:
            out.append(("info", f"{sm['maintenance']} slot(s) closed for maintenance."))
        return out

    # --- CSV import / export
    def import_csv(self, text: str) -> tuple[int, list[str]]:
        """Import slots from CSV. Returns (rows_added, row-by-row error log)."""
        errors: list[str] = []
        reader = csv.DictReader(io.StringIO(text.lstrip("\ufeff")))
        header = [h.strip().lower() for h in (reader.fieldnames or [])]
        missing = {"slot_id", "slot_type"} - set(header)
        if missing:
            return 0, [f"Header: missing required column(s): {', '.join(sorted(missing))}"]
        added = 0
        seen_plates = {s.plate for s in self.slots if s.status == "Occupied"}
        for n, raw in enumerate(reader, start=2):  # row 1 is the header
            row = {(k or "").strip().lower(): (v or "").strip() for k, v in raw.items()}
            try:
                sid = validate_slot_id(row.get("slot_id", ""))
                if self.exists(sid):
                    raise ValidationError(f"Slot {sid} already exists.")
                slot = Slot(sid, validate_type(row.get("slot_type", "")),
                            validate_status(row.get("status", "")), notes=row.get("notes", "")[:100])
                if slot.status == "Occupied":
                    slot.plate = validate_plate(row.get("plate", ""))
                    slot.driver = validate_name(row.get("driver", ""))
                    ci = parse_dt(row.get("check_in", ""))
                    slot.check_in = ci.strftime(DT_FMT)
                    if row.get("expected_out"):
                        eo = parse_dt(row["expected_out"])
                        if eo <= ci:
                            raise ValidationError("expected_out must be after check_in.")
                        slot.expected_out = eo.strftime(DT_FMT)
                    if slot.plate in seen_plates:
                        raise ValidationError(f"Plate {slot.plate} already parked elsewhere.")
                    seen_plates.add(slot.plate)
                elif slot.status == "Reserved":
                    slot.driver = validate_name(row.get("driver", ""))
                self.slots.append(slot)
                added += 1
            except ValidationError as e:
                errors.append(f"Row {n}: {e}")
        self.slots.sort(key=lambda s: s.slot_id)
        if added:
            self.save()
        return added, errors

    def export_csv(self) -> str:
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=CSV_FIELDS, extrasaction="ignore", lineterminator="\n")
        w.writeheader()
        for s in self.slots:
            w.writerow(asdict(s))
        return buf.getvalue()

    def export_markdown(self, now: datetime | None = None) -> str:
        now = now or now_min()
        sm = self.summary(now)
        L = ["# Parking Slot Register - Summary", f"_Generated {now.strftime(DT_FMT)}_", "",
             "## Overview", "", "| Metric | Value |", "|---|---|",
             f"| Total slots | {sm['total']} |", f"| Available | {sm['available']} |",
             f"| Occupied | {sm['occupied']} |", f"| Reserved | {sm['reserved']} |",
             f"| Maintenance | {sm['maintenance']} |", f"| Occupancy | {sm['occupancy_pct']}% |",
             f"| Completed sessions | {sm['sessions']} |", f"| Revenue | Rs {sm['revenue']} |",
             f"| Avg billed stay | {sm['avg_stay_hours']} h |",
             f"| Peak arrival hour | {sm['peak_hour'] if sm['peak_hour'] is not None else 'n/a'} |", "",
             "## By zone", "", "| Zone | Total | Occupied | Available |", "|---|---|---|---|"]
        L += [f"| {z} | {d['total']} | {d['occupied']} | {d['available']} |"
              for z, d in sm["by_zone"].items()]
        L += ["", "## Last 7 days", "", "| Date | Sessions | Revenue (Rs) |", "|---|---|---|"]
        L += [f"| {d} | {v['sessions']} | {v['revenue']} |" for d, v in sm["daily"].items()]
        L += ["", "## Warnings", ""]
        w = self.warnings(now)
        L += [f"- **{lv.upper()}**: {m}" for lv, m in w] or ["- None"]
        return "\n".join(L) + "\n"

    def export_text(self, now: datetime | None = None) -> str:
        now = now or now_min()
        L = [f"PARKING AUDIT LOG  {now.strftime(DT_FMT)}", "=" * 60]
        L += [f"[{lv.upper():7}] {m}" for lv, m in self.warnings(now)] or ["No warnings."]
        L += ["", "SLOTS", "-" * 60,
              f"{'Slot':<6}{'Type':<11}{'Status':<13}{'Plate':<13}{'Driver':<16}"]
        L += [f"{s.slot_id:<6}{s.slot_type:<11}{s.status:<13}{s.plate:<13}{s.driver[:15]:<16}"
              for s in self.slots]
        return "\n".join(L) + "\n"
