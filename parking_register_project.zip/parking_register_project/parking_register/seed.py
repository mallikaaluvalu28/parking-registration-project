"""Generate 40 realistic slots + 45 past sessions incl. edge cases.
Run:  python -m parking_register.seed"""
import csv
import random
from datetime import timedelta

from .core import (CSV_FIELDS, DATA_FILE, DT_FMT, ParkingRegister, Session,
                   Slot, calc_fee, now_min)

NAMES = ["Anita Rao", "Ravi Kumar", "Sneha Reddy", "Imran Khan", "Priya Nair",
         "Arjun Das", "Meera Iyer", "Kiran Patel", "Sana Sheikh", "Vikram Singh",
         "Lakshmi Devi", "Rohit Sharma", "Divya Menon", "Farhan Ali", "Nikhil Verma"]
LAYOUT = {"A": ["Car"] * 10, "B": ["Car"] * 8 + ["Accessible"] * 2,
          "C": ["Bike"] * 10, "D": ["EV"] * 4 + ["Car"] * 6}


def plate(rng):
    return f"TS{rng.randint(1, 38):02d}{rng.choice(['AB','CD','EF','GH'])}{rng.randint(1000, 9999)}"


def build(path=DATA_FILE, seed=56) -> ParkingRegister:
    rng = random.Random(seed)
    now = now_min()
    reg = ParkingRegister(path)
    for z, types in LAYOUT.items():
        for i, t in enumerate(types, 1):
            reg.slots.append(Slot(f"{z}-{i:02d}", t))
    used = set()
    # occupied: on-time, overdue and an unusually long stay (edge cases)
    for sid, ago_h, dur_h in [("A-01", 1, 3), ("A-02", 2, 4), ("A-03", 5, 3), ("A-04", 1, 2),
                              ("A-05", 14, 16), ("A-07", 0.5, 8), ("B-01", 3, 6), ("B-02", 1, 1.5),
                              ("B-09", 2, 5), ("C-01", 1, 2), ("C-02", 4, 3), ("C-03", 0.5, 2),
                              ("C-04", 2, 4), ("D-01", 1, 3), ("D-05", 2, 3), ("D-06", 6, 8)]:
        s = next(x for x in reg.slots if x.slot_id == sid)
        ci = now - timedelta(hours=ago_h)
        p = plate(rng)
        while p in used:
            p = plate(rng)
        used.add(p)
        s.status, s.plate, s.driver = "Occupied", p, rng.choice(NAMES)
        s.check_in = ci.strftime(DT_FMT)
        s.expected_out = (ci + timedelta(hours=dur_h)).strftime(DT_FMT)
    for sid, who in [("B-03", "Dean Office"), ("D-02", "Guest Lecturer")]:
        s = next(x for x in reg.slots if x.slot_id == sid)
        s.status, s.driver = "Reserved", who
    for sid, note in [("A-10", "Broken barrier arm"), ("C-10", "Repainting lines")]:
        s = next(x for x in reg.slots if x.slot_id == sid)
        s.status, s.notes = "Maintenance", note
    # history: 45 completed sessions over the last 7 days (short <1h to long 10h stays)
    for _ in range(45):
        s = rng.choice(reg.slots)
        day = now - timedelta(days=rng.randint(0, 6))
        start = day.replace(hour=rng.choice([8, 9, 9, 10, 11, 13, 14]), minute=rng.choice([0, 15, 30, 45]))
        end = start + timedelta(minutes=rng.choice([20, 55, 90, 150, 240, 330, 600]))
        if end > now:
            end = now
            start = min(start, end - timedelta(minutes=30))
        h, fee = calc_fee(s.slot_type, start, end)
        reg.sessions.append(Session(s.slot_id, s.slot_type, plate(rng), rng.choice(NAMES),
                                    start.strftime(DT_FMT), end.strftime(DT_FMT), h, fee))
    reg.sessions.sort(key=lambda x: x.check_out)
    reg.save()
    return reg


def write_sample_csv(reg, out="sample_data/slots_sample.csv"):
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=CSV_FIELDS, extrasaction="ignore")
        w.writeheader()
        for s in reg.slots:
            w.writerow(s.__dict__)


if __name__ == "__main__":
    r = build()
    write_sample_csv(r)
    print(f"Seeded {len(r.slots)} slots and {len(r.sessions)} sessions -> {DATA_FILE}")
