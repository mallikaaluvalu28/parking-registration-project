"""Parking Slot Register - core package (standard library only)."""
from .core import (ParkingRegister, Slot, Session, ValidationError,
                   ZONE_HINT, SLOT_TYPES, STATUSES, RATE_PER_HOUR)
