# Build Plan - Parking Slot Register (Project #56)

**Stack:** Python 3.10+ standard-library core, **Streamlit** UI (pandas comes with it), JSON persistence.
Why Streamlit: fastest path to a polished demo (forms, metrics, charts, downloads) with no front-end code.

## Architecture
| Layer | File | Responsibility |
|---|---|---|
| Core (no deps) | `parking_register/core.py` | validation, dataclasses, business rules, JSON storage, search, summary, warnings, CSV import, exports |
| Seed | `parking_register/seed.py` | 40 slots + 45 sessions incl. edge cases, sample CSV |
| UI | `app.py` | Streamlit pages; calls core only, never touches files |
| Tests | `tests/test_core.py` | 10 unit tests (validation, fees, persistence, corruption, import) |

## Data model
- **Slot**: slot_id (`A-01`), slot_type (Car/Bike/EV/Accessible), status (Available/Occupied/Reserved/Maintenance), plate, driver, check_in, expected_out, notes
- **Session** (history): slot, plate, driver, check_in, check_out, hours_billed, fee
- Storage: `data/parking.json`, written atomically (temp file + replace)

## Business rules
- Billing per started hour, minimum 1 h. Rs/hour: Car 20, Bike 10, EV 30, Accessible 0
- A plate can occupy only one slot; reserved slots accept only the reserved driver
- Occupied slots cannot be closed or deleted; check-out creates a Session record
- Occupancy % = occupied / (total - maintenance)

## Requirement coverage
| SRS item | Where |
|---|---|
| Interactive interface | Streamlit sidebar menu, 6 pages |
| Defensive validation | `validate_*` in core; UI shows errors, never crashes |
| Core logic | check_in / check_out / reserve / fee calc |
| Persistence | JSON, survives restart; corrupt/missing file auto-recovered |
| Search | keyword + status/type/zone filters, session history search |
| Executive summary | Dashboard metrics, per-zone and 7-day charts, peak hour, avg stay |
| Stretch: exports | Markdown, plain-text audit log, CSV |
| Stretch: warnings | overdue, long stay (>12 h), occupancy >= 90%, full zone |
| Stretch: GUI | Streamlit |
| Stretch: bulk import | CSV import with row-by-row error log |

## Milestones (hackathon timeline)
1. **Hour 0-1** Setup, venv, repo, data model
2. **Hour 1-3** Validation + core logic + JSON storage + unit tests
3. **Hour 3-5** Search, summary, warnings, exports, CSV import
4. **Hour 5-7** Streamlit pages and polish
5. **Hour 7-8** Seed data, demo rehearsal, README

## Demo script (5 min)
1. Open dashboard: metrics, alerts (overdue vehicles show red)
2. Check in with bad plate `ABC` and hours `99` - show validation messages
3. Check in correctly, then check out and show the bill
4. Search `TS08` / filter Occupied
5. Stop and rerun `streamlit run app.py` - state is preserved
6. Import `sample_data/import_with_errors.csv` - show error log
7. Download Markdown report
