"""Parking Slot Register - Streamlit UI.   Run:  streamlit run app.py"""
import pandas as pd
import streamlit as st

from parking_register import (ParkingRegister, RATE_PER_HOUR, SLOT_TYPES,
                              STATUSES, ValidationError, ZONE_HINT)
from parking_register.core import now_min

st.set_page_config(page_title="Parking Slot Register", page_icon="🅿️", layout="wide")
ICON = {"Available": "🟢", "Occupied": "🔴", "Reserved": "🟡", "Maintenance": "🛠️"}


def flash(kind, msg):
    st.session_state["flash"] = (kind, msg)


def show_flash():
    if "flash" in st.session_state:
        kind, msg = st.session_state.pop("flash")
        getattr(st, kind)(msg)


def run(action, ok_msg):
    """Run a register action; show validation problems instead of crashing."""
    try:
        res = action()
        flash("success", ok_msg(res) if callable(ok_msg) else ok_msg)
    except ValidationError as e:
        flash("error", str(e))
    st.rerun()


def slots_df(slots):
    return pd.DataFrame([{"Slot": s.slot_id, "Type": s.slot_type, "Status": f"{ICON[s.status]} {s.status}",
                          "Plate": s.plate, "Driver": s.driver, "Check-in": s.check_in,
                          "Expected out": s.expected_out, "Notes": s.notes} for s in slots])


reg = ParkingRegister.load()
if reg.load_notice:
    st.warning(reg.load_notice)

st.sidebar.title("🅿️ Parking Slot Register")
st.sidebar.caption("Small campus parking area")
page = st.sidebar.radio("Menu", ["Dashboard", "Slot Map", "Check-in / Check-out",
                                 "Search", "Reports & Export", "Import CSV"])
st.sidebar.divider()
st.sidebar.caption("Rates (Rs/hour): " + ", ".join(f"{k} {v}" for k, v in RATE_PER_HOUR.items()))
st.sidebar.caption("Billed per started hour, minimum 1 hour.")
show_flash()

# ------------------------------------------------------------------ dashboard
if page == "Dashboard":
    st.title("Dashboard")
    sm = reg.summary()
    c = st.columns(5)
    c[0].metric("Total slots", sm["total"])
    c[1].metric("Available", sm["available"])
    c[2].metric("Occupied", sm["occupied"])
    c[3].metric("Occupancy", f"{sm['occupancy_pct']}%")
    c[4].metric("Revenue (Rs)", sm["revenue"])
    st.progress(min(sm["occupancy_pct"] / 100, 1.0), text=f"Lot occupancy {sm['occupancy_pct']}%")
    st.subheader("Alerts")
    warns = reg.warnings()
    if not warns:
        st.success("No alerts - everything looks normal.")
    for level, msg in warns:
        {"error": st.error, "warning": st.warning, "info": st.info}[level](msg)
    left, right = st.columns(2)
    with left:
        st.subheader("Occupancy by zone")
        zdf = pd.DataFrame(sm["by_zone"]).T.rename(columns=str.title)
        st.bar_chart(zdf[["Occupied", "Available"]])
    with right:
        st.subheader("Sessions - last 7 days")
        ddf = pd.DataFrame(sm["daily"]).T
        st.bar_chart(ddf["sessions"])
    st.caption(f"Completed sessions: {sm['sessions']} | Avg billed stay: {sm['avg_stay_hours']} h | "
               f"Peak arrival hour: {sm['peak_hour'] if sm['peak_hour'] is not None else 'n/a'}:00")

# ------------------------------------------------------------------- slot map
elif page == "Slot Map":
    st.title("Slot Map")
    st.caption("🟢 Available  🔴 Occupied  🟡 Reserved  🛠️ Maintenance")
    zones = sorted({s.zone for s in reg.slots})
    for z in zones:
        st.subheader(f"Zone {z}")
        zs = [s for s in reg.slots if s.zone == z]
        for row in range(0, len(zs), 5):
            cols = st.columns(5)
            for col, s in zip(cols, zs[row:row + 5]):
                with col.container(border=True):
                    st.markdown(f"**{ICON[s.status]} {s.slot_id}**")
                    st.caption(f"{s.slot_type} - {s.status}" + (f"\n\n{s.plate}" if s.plate else ""))
    st.divider()
    a, b = st.columns(2)
    with a:
        st.subheader("Add slot")
        with st.form("add_slot", clear_on_submit=True):
            sid = st.text_input("Slot ID", placeholder="E-01", help=ZONE_HINT)
            typ = st.selectbox("Type", SLOT_TYPES)
            note = st.text_input("Notes (optional)", max_chars=100)
            if st.form_submit_button("Add slot"):
                run(lambda: reg.add_slot(sid, typ, note), lambda s: f"Added slot {s.slot_id}.")
    with b:
        st.subheader("Manage slot")
        if reg.slots:
            pick = st.selectbox("Slot", [s.slot_id for s in reg.slots])
            cur = reg.get(pick)
            st.write(f"Current status: {ICON[cur.status]} **{cur.status}**")
            if cur.status == "Maintenance":
                if st.button("Reopen slot"):
                    run(lambda: reg.set_maintenance(pick, False), "Slot reopened.")
            elif cur.status != "Occupied":
                if st.button("Close for maintenance"):
                    run(lambda: reg.set_maintenance(pick, True), "Slot closed for maintenance.")
            if cur.status == "Available":
                who = st.text_input("Reserve for (name)")
                if st.button("Reserve"):
                    run(lambda: reg.reserve(pick, who), "Slot reserved.")
            if cur.status == "Reserved" and st.button("Cancel reservation"):
                run(lambda: reg.cancel_reservation(pick), "Reservation cancelled.")
            if cur.status in ("Available", "Maintenance"):
                if st.checkbox(f"Confirm delete {pick}") and st.button("Delete slot", type="primary"):
                    run(lambda: reg.remove_slot(pick), f"Deleted {pick}.")

# ------------------------------------------------------------- check-in / out
elif page == "Check-in / Check-out":
    st.title("Check-in / Check-out")
    left, right = st.columns(2)
    with left:
        st.subheader("Check in a vehicle")
        free = [s.slot_id for s in reg.slots if s.status in ("Available", "Reserved")]
        if not free:
            st.warning("No free slots right now.")
        else:
            with st.form("checkin"):
                sid = st.selectbox("Slot", free)
                plate = st.text_input("Vehicle plate", placeholder="TS08AB1234")
                driver = st.text_input("Driver name")
                hours = st.text_input("Expected stay (hours, 0.5-24)", value="2")
                if st.form_submit_button("Check in"):
                    run(lambda: reg.check_in(sid, plate, driver, hours),
                        lambda s: f"{s.plate} parked in {s.slot_id}. Expected out {s.expected_out}.")
    with right:
        st.subheader("Check out a vehicle")
        occ = [s for s in reg.slots if s.status == "Occupied"]
        if not occ:
            st.info("No vehicles currently parked.")
        else:
            label = {s.slot_id: f"{s.slot_id} - {s.plate} ({s.driver})" for s in occ}
            sid = st.selectbox("Parked vehicle", list(label), format_func=label.get)
            slot = reg.get(sid)
            st.caption(f"In: {slot.check_in} | Expected out: {slot.expected_out}")
            if st.button("Check out & bill"):
                run(lambda: reg.check_out(sid),
                    lambda x: f"{x.plate} left {x.slot_id}. {x.hours_billed} h billed = Rs {x.fee}.")
    st.divider()
    st.subheader("Currently parked")
    parked = [s for s in reg.slots if s.status == "Occupied"]
    if parked:
        st.dataframe(slots_df(parked).drop(columns=["Notes"]), hide_index=True, use_container_width=True)

# --------------------------------------------------------------------- search
elif page == "Search":
    st.title("Search")
    c = st.columns([3, 1, 1, 1])
    kw = c[0].text_input("Keyword (slot, plate, driver, notes)")
    status = c[1].selectbox("Status", [""] + STATUSES, format_func=lambda v: v or "Any")
    typ = c[2].selectbox("Type", [""] + SLOT_TYPES, format_func=lambda v: v or "Any")
    zone = c[3].selectbox("Zone", [""] + sorted({s.zone for s in reg.slots}), format_func=lambda v: v or "Any")
    hits = reg.search(kw, status, typ, zone)
    st.write(f"**{len(hits)}** matching slot(s)")
    if hits:
        st.dataframe(slots_df(hits), hide_index=True, use_container_width=True)
    st.subheader("Past sessions")
    sess = reg.search_sessions(kw)
    if sess:
        sdf = pd.DataFrame([s.__dict__ for s in sess]).iloc[::-1]
        st.dataframe(sdf, hide_index=True, use_container_width=True)
    else:
        st.caption("No past sessions match.")

# -------------------------------------------------------------------- reports
elif page == "Reports & Export":
    st.title("Reports & Export")
    sm = reg.summary()
    st.markdown(reg.export_markdown())
    st.subheader("Download")
    c = st.columns(3)
    stamp = now_min().strftime("%Y%m%d_%H%M")
    c[0].download_button("Markdown summary", reg.export_markdown(), f"parking_summary_{stamp}.md", "text/markdown")
    c[1].download_button("Plain-text audit log", reg.export_text(), f"parking_audit_{stamp}.txt", "text/plain")
    c[2].download_button("Slots CSV", reg.export_csv(), f"parking_slots_{stamp}.csv", "text/csv")

# ------------------------------------------------------------------ import csv
elif page == "Import CSV":
    st.title("Bulk Import")
    st.caption("Required columns: slot_id, slot_type. Optional: status, plate, driver, check_in, "
               "expected_out, notes. Dates look like 2026-11-25 14:30.")
    up = st.file_uploader("Choose a CSV file", type="csv")
    if up and st.button("Import", type="primary"):
        try:
            text = up.getvalue().decode("utf-8-sig")
        except UnicodeDecodeError:
            st.error("File is not valid UTF-8 text.")
        else:
            added, errors = reg.import_csv(text)
            (st.success if added else st.warning)(f"Imported {added} row(s); {len(errors)} rejected.")
            if errors:
                st.subheader("Row-by-row error log")
                st.dataframe(pd.DataFrame({"Problem": errors}), hide_index=True, use_container_width=True)
                st.download_button("Download error log", "\n".join(errors), "import_errors.txt")
